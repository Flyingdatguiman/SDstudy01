module Kiosk {
}