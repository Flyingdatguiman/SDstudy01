package com.kiosk.main;

import com.kiosk.product.Product;

public class Order {
	public Product selectedProduct;

	public Order(Product selectedProduct) {
		this.selectedProduct = selectedProduct;
	}

}
