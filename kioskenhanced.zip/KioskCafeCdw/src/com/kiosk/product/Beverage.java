package com.kiosk.product;

public class Beverage extends Product {
	
	public Beverage(String xx, int yy) {
		super(xx, yy);
	}

}
